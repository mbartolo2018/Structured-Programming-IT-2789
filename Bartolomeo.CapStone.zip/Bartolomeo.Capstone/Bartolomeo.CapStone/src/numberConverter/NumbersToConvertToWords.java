package numberConverter;

import javax.swing.JOptionPane;

public class NumbersToConvertToWords
{
	public NumbersToConvertToWords()
	{
		//had trouble with negative numbers with three or more digits
		//would place the word negative twice
		/*
		 *
		 *had issues with the decimal being displayed as well with the decimal
		identifier
		*/

		String message;
		String numberInput;
		String tempNumber = "";
		String theResult = "";

		message = "please input the number to convert to words";
		numberInput = inputInteger(message);
  
		// adapt for thousands = 4 to 6 digits
		if (numberInput.length() > 3)
		{
			for (int n = 0; n < numberInput.length() - 3; n++)
			{
				tempNumber += numberInput.charAt(n);
				// System.out.println("\ttempNumber = " + tempNumber);
			}

			theResult += threeDigitNumbeIdentifier(tempNumber) + " thousand ";
		}

		// final three digits
		theResult += threeDigitNumbeIdentifier(numberInput);

		message = "your number, " + numberInput + " in words is " + theResult;

		JOptionPane.showMessageDialog(null, message);

		// System.out.println("the whole number is " + theResult);
	}

	public String threeDigitNumbeIdentifier(String theNumber)
	{
		String theResult;

		theResult = onesDecoder(theNumber);

		theResult = decodeHundreds(theNumber);

		theResult = decimalPlaceIdentifier(theNumber);

		theResult = negativeDecoder(theNumber);

		theResult += tensDecoder(theNumber);

		if (theNumber.length() > 1 && findChar(theNumber, 2) != '1')
			theResult += onesDecoder(theNumber);

		return theResult;
	}

	public String inputInteger(String message)
	{
		String tempInput;

		do
		{
			tempInput = JOptionPane.showInputDialog(message);
		} while (!canBeInt(tempInput));

		return tempInput;
	}

	public boolean canBeInt(String s)
	{
		for (int count = 0; count < s.length(); count++)
		{
			if (count == 0 && (s.charAt(0) == '+' || s.charAt(0) == '-' || s.charAt(0) == '.'))
				continue;

			if (s.charAt(count) < '0' || s.charAt(count) > '9')
				return false;
		}

		return true;
	}

	public String onesDecoder(String theNumber)
	{
		if (theNumber.length() > 0)
		{
			char theChar = findChar(theNumber, 1);

			return decodeOnesAndHundredsChar(theChar);
		}
		return "";
	}

	public String tensDecoder(String theNumber)
	{
		if (theNumber.length() > 1)
		{
			char theChar = findChar(theNumber, 2);

			if (theChar == '1')
			{
				return decodeTeens(theNumber);
			} else
			{
				return decodeTensDigits(theChar, theNumber) + " ";
			}
		}

		return "";
	}

	public String decodeHundreds(String theNumber)
	{
		if (theNumber.length() > 2)
		{
			char theChar = findChar(theNumber, 3);

			return decodeOnesAndHundredsChar(theChar) + " hundred ";
		}

		return "";
	}

	public String negativeDecoder(String theNumber)
	{
		if (theNumber.charAt(0) == '-')
		{
			return " negative ";
		}
		return "";
	}

	public String decimalPlaceIdentifier(String theNumber)
	{
		if (theNumber.charAt(0) == '.')
		{
			return "point ";
		}
		return "";
	}

	public String decodeOnesAndHundredsChar(char theChar)
	{
		String theWord;

		switch (theChar)
		{
		case '0':
			theWord = "";
			break;
		case '1':
			theWord = "one";
			break;
		case '2':
			theWord = "two";
			break;
		case '3':
			theWord = "three";
			break;
		case '4':
			theWord = "four";
			break;
		case '5':
			theWord = "five";
			break;
		case '6':
			theWord = "six";
			break;
		case '7':
			theWord = "seven";
			break;
		case '8':
			theWord = "eight";
			break;
		case '9':
			theWord = "nine";
			break;
		default:
			theWord = "";
			break;
		}

		return theWord;
	}

	public String decodeTensDigits(char theChar, String theNumber)
	{
		String theWord;

		switch (theChar)
		{
		case '0':
			theWord = "";
			break;
		case '1':
			theWord = decodeTeens(theNumber);
			break;
		case '2':
			theWord = "twenty";
			break;
		case '3':
			theWord = "thirty";
			break;
		case '4':
			theWord = "fourty";
			break;
		case '5':
			theWord = "fifty";
			break;
		case '6':
			theWord = "sixty";
			break;
		case '7':
			theWord = "seventy";
			break;
		case '8':
			theWord = "eighty";
			break;
		case '9':
			theWord = "ninety";
			break;
		default:
			theWord = "";
			break;
		}

		return theWord;
	}

	public String decodeTeens(String theNumber)
	{
		String theWord;
		char theChar = findChar(theNumber, 1);
		
		// the tens place character is a '1'
		
		switch (theChar)
		{
		case '0':
			theWord = "ten";
			break;
		case '1':
			theWord = "eleven";
			break;
		case '2':
			theWord = "twelve";
			break;
		case '3':
			theWord = "thirteen";
			break;
		case '4':
			theWord = "fourteen";
			break;
		case '5':
			theWord = "fifteen";
			break;
		case '6':
			theWord = "sixteen";
			break;
		case '7':
			theWord = "seventeen";
			break;
		case '8':
			theWord = "eighteen";
			break;
		case '9':
			theWord = "nineteen";
			break;
		default:
			theWord = "";
			break;
		}

		return theWord;
	}

	public char findChar(String theNumber, int theDigit)
	{
		char theChar;
		int numChars = theNumber.length();
		numChars -= theDigit;

		theChar = theNumber.charAt(numChars);

		// System.out.println("theChar = " + theChar);

		return theChar;
	}
}
