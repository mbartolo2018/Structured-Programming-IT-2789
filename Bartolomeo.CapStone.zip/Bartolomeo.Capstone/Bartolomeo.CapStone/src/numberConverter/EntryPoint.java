package numberConverter;

public class EntryPoint
{

	public static void main(String[] args)
	{
		new NumbersToConvertToWords();
	}

}
